import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user.model';

@Injectable()
export class UserService {
  constructor(private http: HttpClient) { }
  // baseUrl: string = 'http://localhost:8080/user-portal/users';// baseUrl: string = 'http://srmpc840:8080/user-portal/users';

  baseUrl = 'http://localhost:8101/sample';


  // erp/userDetails';
  getUsers() {
    return this.http.get<User[]>(this.baseUrl + '/login');
  }
  createUser(user: User) {
    //  return this.http.post(this.baseUrl, user);
    console.log('inside create');
    return this.http.post(this.baseUrl + '/login', user);
  //  return this.http.post(this.baseUrl + '/login', user).map<any>(res =>  {
  //       if (res.json().status === 2) {
  //        console.log(res.json.status);
  //       }
  //       return res.json();
  //     });
  }
  }
