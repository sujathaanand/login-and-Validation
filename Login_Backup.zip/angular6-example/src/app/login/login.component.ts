import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {first} from 'rxjs/operators';


import { HttpClient } from '@angular/common/http';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  invalidLogin = false;

constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserService) { }

  onSubmit() {
    this.userService.createUser(this.loginForm.value)
     .subscribe( data => {
  const myObjStr = JSON.stringify(data);

  const x = JSON.parse(myObjStr);

 if ((x.status === '2'))  {
  this.router.navigate(['list-user']);

  }

   if ((x.status === '1'))  {
    this.router.navigate(['welcome']);

  }

this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    } else {
      this.invalidLogin = true;
    }

      });

    }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  }
