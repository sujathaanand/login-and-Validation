export class User {

  id: number;
  sponson_id: number;
  name: string;
  address1: string;
  address2: string;
  city: string;
  username: string;
  password: string;
  role_id: string;
  email: string;
  status: string;
}
