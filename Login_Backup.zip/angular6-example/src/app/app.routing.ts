import { RouterModule, Routes } from '@angular/router';
import {LoginComponent} from './login/login.component';
import {ListUserComponent} from './list-user/list-user.component';
import { WelcomeComponent } from './welcome/welcome.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'list-user', component: ListUserComponent },
  { path: 'welcome', component: WelcomeComponent },
  {path : '', component : LoginComponent}
];

export const routing = RouterModule.forRoot(routes);
