package com.srmt.erp.employee.dto;

import com.srmt.erp.employee.model.Login;

public class LoginDto {
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public static LoginDto convertToDTO(Login login) {

		LoginDto logindto = new LoginDto();
		logindto.setStatus(login.getStatus());
		return logindto;

	}
}
