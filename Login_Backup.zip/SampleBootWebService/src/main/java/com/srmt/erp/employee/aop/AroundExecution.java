package com.srmt.erp.employee.aop;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AroundExecution {

	private static final Logger logger = LogManager.getLogger(AroundExecution.class);
	
	@Pointcut("within(@org.springframework.stereotype.Repository *)"
			+ " || within(@org.springframework.stereotype.Service *)"
			+ " || within(@org.springframework.web.bind.annotation.RestController *)")
	public void springBeanPointcut() {}

	@Pointcut("within(com.srmt.erp.employee.dao..*)" + " || within(com.srmt.erp.employee.service..*)"
			+ " || within(com.srmt.erp.employee.controller..*)")
	public void applicationPackagePointcut() {}

	@Around("applicationPackagePointcut() && springBeanPointcut()")
	public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
		long start = System.currentTimeMillis();
		Object proceed = joinPoint.proceed();
		long executionTime = System.currentTimeMillis() - start;
		System.out.println(joinPoint.getSignature() + " executed in " + executionTime + "ms");
		logger.debug(joinPoint.getSignature() + " executed in " + executionTime + "ms");
		return proceed;
	}
}
