package com.srmt.erp.employee.dao;

import com.srmt.erp.employee.model.Login;

public interface LoginDao {
	public Login login(Login login);
	/*public String create(Login login);*/

	public Login getLoginById(int id);

}
