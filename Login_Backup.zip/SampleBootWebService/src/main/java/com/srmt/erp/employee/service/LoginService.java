package com.srmt.erp.employee.service;

import com.srmt.erp.employee.dto.LoginDto;
import com.srmt.erp.employee.model.Login;

public interface LoginService {

	public LoginDto login(Login login);

}
