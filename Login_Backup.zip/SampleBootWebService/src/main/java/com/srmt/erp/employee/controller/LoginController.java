package com.srmt.erp.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.srmt.erp.employee.dto.LoginDto;
import com.srmt.erp.employee.model.Login;
import com.srmt.erp.employee.service.LoginServiceImplementaion;

@RestController
@CrossOrigin(origins = "*")
public class LoginController {
	@Autowired
	private LoginServiceImplementaion loginserviceimplementaion;
	private Login login;

	/*	*//*** Creating a new login ***/
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")

	// @PostMapping("/login")
	public LoginDto login(@RequestBody Login login) {

		//if(login.getUsername()!=null || login.getUsername())
		// System.out.println("uname : " + employee.getUsername());
		// System.out.println("password : " + employee.getPassword());
		LoginDto status = loginserviceimplementaion.login(login);

		System.out.println("In controller: " + status);
		return status;
	}

	@RequestMapping(value = "getlog/{id}", produces = "application/json", method = RequestMethod.GET)
	public Login getAllStudentsid(@PathVariable("id") int id) {
		Login resList = loginserviceimplementaion.getAlllogid(id);
		return resList;
	}
}
