package com.srmt.erp.employee.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "school")

public class Login implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column
	public int id;

	@Column
	public int sponson_id;

	@Column
	public LocalDateTime start_date;

	@Column
	public LocalDateTime end_date;

	@Column
	private String name;

	@Column
	private String address1;

	@Column
	private String address2;

	@Column
	private String city;

	/*
	 * @Column private long contact_no;
	 */
	@Column
	private String username;

	@Column
	private String password;

	@Column
	private String role_id;

	@Column
	private String email;

	private String status;

	public Login() {
		super();
	}

	public Login(int id, int sponson_id, LocalDateTime start_date, LocalDateTime end_date, String name, String address1,
			String address2, String city, String username, String password, String role_id, String email) {
		super();
		this.id = id;
		this.sponson_id = sponson_id;
		this.start_date = start_date;
		this.end_date = end_date;
		this.name = name;
		this.address1 = address1;
		this.address2 = address2;
		this.city = city;
		// this.contact_no = contact_no;
		this.username = username;
		this.password = password;
		this.role_id = role_id;
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSponson_id() {
		return sponson_id;
	}

	public void setSponson_id(int sponson_id) {
		this.sponson_id = sponson_id;
	}

	public LocalDateTime getStart_date() {
		return start_date;
	}

	public void setStart_date(LocalDateTime start_date) {
		this.start_date = start_date;
	}

	public LocalDateTime getEnd_date() {
		return end_date;
	}

	public void setEnd_date(LocalDateTime end_date) {
		this.end_date = end_date;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	/*
	 * public long getContact_no() { return contact_no; }
	 * 
	 * public void setContact_no(long contact_no) { this.contact_no = contact_no; }
	 */

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole_id() {
		return role_id;
	}

	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Login [id=" + id + ", sponson_id=" + sponson_id + ", start_date=" + start_date + ", end_date="
				+ end_date + ", name=" + name + ", address1=" + address1 + ", address2=" + address2 + ", city=" + city
				+ ", username=" + username + ", password=" + password + ", role_id=" + role_id + ", email=" + email
				+ "]";
	}

}
