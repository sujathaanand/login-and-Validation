package com.srmt.erp.employee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.srmt.erp.employee.dao.LoginDao;
import com.srmt.erp.employee.dto.LoginDto;
import com.srmt.erp.employee.model.Login;

@Service
//@Transactional

public class LoginServiceImplementaion implements LoginService {

	@Autowired
	private LoginDao logindao;
	/*
	 * @Override public String create(Login login) {
	 * 
	 * String status = logindao.create(login); return status;
	 * 
	 * // TODO Auto-generated method stub
	 * 
	 * }
	 */

	@Override
	public LoginDto login(Login login) {
		// TODO Auto-generated method stub
		Login status = logindao.login(login);
		System.out.println("service status" + status);
		return LoginDto.convertToDTO(status);

	}

	public Login getAlllogid(int id) {
		return logindao.getLoginById(id);

	}

}
