package com.srmt.erp.employee.dao;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.srmt.erp.employee.model.Login;

@Repository
//@Transactional(propagation = Propagation.REQUIRED)

public class LoginDaoImplements implements LoginDao {

	@Autowired
	private SessionFactory sessionfactory;

	@Override
	public Login login(Login login) {
		System.out.println("employee: " + login.getUsername());
		System.out.println("employee: " + login.getPassword());

		String userna = login.getUsername().replaceAll(" ", "");
		if (userna == null || userna.isEmpty()) {

			login.setStatus("Username is required");
		}

		else if (login.getPassword() == null || login.getPassword().isEmpty()) {
			login.setStatus("password is required");
		}

		 else  {

			try {

				//@SuppressWarnings("rawtypes")
				Query query1 = (Query) sessionfactory.openSession()
						.createQuery("Select e from Login e where e.username='" + login.getUsername()
								+ "' and e.password='" + login.getPassword() + "'");
				Login e = (Login) query1.getSingleResult();
				if (e != null) {
					System.out.println(e.getRole_id());
					login.setStatus(e.getRole_id());

				}

			} catch (Exception e) {
				System.out.println("invalid");
				login.setStatus("Invalid credentials");
			}

		}
		return login;
	}

	@Override
	public Login getLoginById(int id) {
		return sessionfactory.openSession().get(Login.class, id);

	}

}
